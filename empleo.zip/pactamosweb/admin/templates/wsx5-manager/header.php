<img class="logo" src="images/wsx5manager_icon.png" alt="WebSite X5 Manager" />
<div class="introduction">
	<div class="padding-left margin-left border-bottom-2 border-mute-light uppercase"><?php echo l10n("admin_manager_subtitle", "The essential WebSite X5 tool to manage your sites from mobile.") ?></div><br/>
	<div class="text-light margin-top-10 padding-left margin-left"><?php echo l10n("admin_manager_introduction", "Access the control panels on all your websites from your smartphone or tablet with the WebSite X5 Manager app.") ?></div>
</div>
<div class="clearfix"></div>
