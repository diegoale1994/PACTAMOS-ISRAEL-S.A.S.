<?php ob_start() ?>

        <div class="container">
         <div class="col-md-12">
      <h1 class="color-white text-center ">Hojas de Vida</h1><br>
    </div>
        </div>
      </header><!-- end main-header -->

<div class="modal fade" id="new_resume" tabindex="-1" role="dialog" aria-labelledby="crediavales-label" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="project-12-label"><center>Nueva hoja de Vida</center></h4>
      </div>
      <div class="modal-body">
        <div class="row">
           <form method="POST" action="../index.php/create_resume">
            <div class="col-md-2">
              <label>Tipo Documento</label>
              <select class="form-control" type="text" name="tipo_documento" >
                <option>CC</option>
                <option>CE</option>
              </select>
            </div>
            <div class="col-md-4">
              <label>Documento</label>
              <input class="form-control" type="text" name="documento" >
            </div>
            <div class="col-md-6">
              <label>Primer Nombre</label>
              <input class="form-control" type="text" name="nombre1">
            </div>
            <div class="col-md-6">
              <label>Segundo Nombre</label>
              <input class="form-control" type="text" name="nombre2">
            </div>
            <div class="col-md-6">
              <label>Primer Apellido</label>
              <input class="form-control" type="text" name="apellido1" required>
            </div>
            <div class="col-md-6">
              <label>Segundo Apellido</label>
              <input class="form-control" type="text" name="apellido2" required>
            </div>
            <div class="col-md-6">
              <label>Profesión</label>
              <input class="form-control" type="text" name="profesion" required>
            </div>
            <div class="col-md-6">
              <label>Departamento</label>
              <input class="form-control" type="text" name="departamento" required>
            </div>
            <div class="col-md-6">
              <label>Municipio</label>
              <input class="form-control" type="text" name="ciudad" required>
            </div>
            <div class="col-md-6">
              <label>Dirección</label>
              <input class="form-control" type="text" name="direccion" required>
            </div>
            <div class="col-md-6">
              <label>Teléfono</label>
              <input class="form-control" type="text" name="telefono" required>
            </div>

            <div class="col-md-12">
              <br>
              <input class="form-control " type="submit" value="Crear">
            </div>
            
          </form>
          </div>
    </div>
    </div>
  </div>
</div>


      <!-- body-content -->
      <div class="body-content clearfix" >
        <div class="bg-color1 block-section line-bottom">
          <div class="container">
            <div class="panel panel-default">
              <div class="panel-heading">
              <a type="button" class="btn btn-success glyphicon glyphicon-plus" data-toggle="modal"  data-target="#new_resume"> </a>
              
              </div>
              <div class="panel-body">
                <table    class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead id="nom2" name="rol">
                      <tr>
                        <th data-field="id" data-sortable="true" data-align="center" id="name">Nombre</th> 
                        <th data-field="id" data-sortable="true" data-align="center" id="name">Profesión</th> 
                        <th data-field="name" data-sortable="true" data-align="center" id="status">Departamento</th>
                        <th data-field="name" data-sortable="true" data-align="center" id="status">Municipio</th>
                        <th data-field="name" data-sortable="true" data-align="center" id="status">Dirección</th>
                        <th data-field="id" data-sortable="true" data-align="center" id="name">Teléfono</th>
                        <th>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>                    
                      <?php  if(isset($resume)){foreach($resume as $res): ?>
                        <tr> 
                          <th><?php echo $res["nombre1"].' '.$res["apellido1"] ?></th> 
                          <th><?php echo $res["Profesion"] ?></ht>  
                          <th><?php echo $res["departamento"] ?></th>
                          <th><?php echo $res["ciudad"] ?></th> 
                          <th><?php echo $res["direccion"] ?></th> 
                          <th><?php echo $res["telefono"] ?></th>    
                          <th><form action="../index.php/update_resume" method="POST">
                                <input type="hidden" name="doc" value="<?php echo $res["documento"] ?>">
                                <input type="submit" class="btn btn-primary"> Ingresar más Información
                              </form>
                          </th>                       
                          <th><a href="/empleo/index.php/exp_lab_del?delete=<?php echo $exp['id_exp'] ?>" class="btn btn-danger"> Eliminar</a></th>
                        </tr>
                      <?php endforeach ;}?>
                    </tbody>
                </table>
              </div>
            </div>

              
          </div>
        </div>
      </div>

   

<?php $contenido=ob_get_clean(); ?>
<?php include "plantilla/plantilla_base.php"; ?>
 