<?php ob_start() ?>
      
      </header><!-- end main-header -->


      <!-- body-content -->
      <div class="body-content clearfix" >

        <div class="bg-color1 block-section line-bottom">
          <div class="container">
            <div class="embed-responsive embed-responsive-16by9">
              <iframe class="embed-responsive-item" src="../brochure/brochure pactamos proyecto.html"></iframe>
            </div>
          </div>
        </div>

      </div><!--end body-content -->

<?php $contenido=ob_get_clean(); ?>
<?php include "plantilla/plantilla_base.php"; ?>
 